<?php
 phpinfo();
?>
